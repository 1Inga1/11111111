from . import db

UserGroup = db.Table(
    'users_groups', db.Model.metadata,
    db.Column('user_id', db.Integer, db.ForeignKey('users.id')),
    db.Column('group_id', db.Integer, db.ForeignKey('groups.id'))
)


QuestionsTasks = db.Table(
    'questions_tasks', db.Model.metadata,
    db.Column('task_id', db.Integer, db.ForeignKey('tasks.id')),
    db.Column('question_id', db.Integer, db.ForeignKey('questions.id'))
)


UserRole = db.Table(
    'user_role', db.Model.metadata,
    db.Column('user_id', db.Integer, db.ForeignKey('users.id')),
    db.Column('role_id', db.Integer, db.ForeignKey('roles.id'))
)


GroupsTasks = db.Table(
    'groups_tasks', db.Model.metadata,
    db.Column('task_id', db.Integer, db.ForeignKey('tasks.id')),
    db.Column('group_id', db.Integer, db.ForeignKey('groups.id'))
)


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, unique=True)
    email = db.Column(db.String(150), unique=True)
    firstName = db.Column(db.String(150))
    password = db.Column(db.String(150))

    teachers_group = db.relationship("Group")

    results = db.relationship('Result')
    roles = db.relationship('Role', secondary=UserRole)
    groups = db.relationship('Group', secondary=UserGroup, back_populates="members")

    status = db.Column(db.String(16))


class Group(db.Model):
    __tablename__ = 'groups'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, unique=True)

    teacher = db.relationship('User')
    teacher_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    members = db.relationship('User', secondary=UserGroup, back_populates="groups")
    tasks = db.relationship('Task', secondary=GroupsTasks, back_populates="groups")


class Role(db.Model):
    __tablename__ = 'roles'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)


class Question(db.Model):
    __tablename__ = 'questions'

    id = db.Column(db.Integer, primary_key=True, unique=True)
    text = db.Column(db.String(255))
    answer = db.Column(db.String(63))

    tasks = db.relationship('Task', secondary=QuestionsTasks, back_populates="questions")

    module_id = db.Column(db.Integer, db.ForeignKey('module.id'))
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'))

    def check(self, ans):
        if str(ans) == self.answer:
            return True
        else:
            return False


class Task(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key=True, unique=True)
    name = db.Column(db.String(31), unique=True)

    beginning_time = db.Column(db.String(31))
    ending_time = db.Column(db.String(31))

    groups = db.relationship('Group', secondary=GroupsTasks, back_populates="tasks")
    questions = db.relationship('Question', secondary=QuestionsTasks, back_populates="tasks")

    status = db.Column(db.String(31))


class Module(db.Model):
    __tablename__ = 'module'

    id = db.Column(db.Integer, primary_key=True, unique=True)
    name = db.Column(db.String(31), unique=True, nullable=False)

    questions = db.relationship('Question')


class Result(db.Model):
    __tablename__ = "results"
    id = db.Column(db.Integer, primary_key=True, unique=True)

    student = db.relationship("User")
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    content = db.Column(db.String(1024))
    test_id = db.Column(db.Integer)
    percentage = db.Column(db.Float)
    mark = db.Column(db.Integer)
    task_name = db.Column(db.String(64))